package com.amazon.market.dao;

import com.amazon.market.entity.DeliverypersonZone;;

public interface DeliverypersonZoneDAO {
 
    public DeliverypersonZone getDeliverypersonZone(int id);
    
}